Just place the `nimdsphax` folder itself in `/3ds/` on the sdcard, not the individual contents.
The exploit tries to execute immediately after running.
On *hax xml takeover runs, there's a chance of it failing to run on a red screen, this is an xml takeover issue.
Despite using nim:s, online connection is not required.

